<img
              src="<?php echo e(url('/frontend/images/content/logo.png')); ?>"
              alt="Luxspace | Fulfill your house with beautiful furniture"
            /><?php /**PATH C:\laragon\www\luxspace\resources\views/vendor/jetstream/components/application-logo.blade.php ENDPATH**/ ?>