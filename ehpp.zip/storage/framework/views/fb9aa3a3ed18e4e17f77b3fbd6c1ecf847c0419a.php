<img
              src="<?php echo e(url('/frontend/images/content/logos.png')); ?>"
              alt="Luxspace | Fulfill your house with beautiful furniture"
            /><?php /**PATH C:\laragon\www\ehpp\resources\views/vendor/jetstream/components/application-mark.blade.php ENDPATH**/ ?>