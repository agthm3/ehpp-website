'<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Detail Pakan
        </h2>
     <?php $__env->endSlot(); ?>
    <?php dd($hpp_record); ?>;

    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <h2 class="font-semibold text-lg text-gray-800 leading-tight mb-5">Pakan Detail</h2>
            <br>
            <form action="" method="POST">
                <?php echo csrf_field(); ?>

                <button class="bg-green-500 text-white rounded-md px-6 py-1 m-2" type="submit">Hitung</button>
            </form>
            <br>
            <hr>



            <div class="col-lg-6"><a href="" class="bg-green-500 text-white rounded-md px-6 py-1 m-2">
                    Edit </a>



            </div>





            <div class="row">



            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
'
<?php /**PATH C:\laragon\www\ehpp\resources\views/pages/dashboard/hpp/show.blade.php ENDPATH**/ ?>