

<?php $__env->startSection('content'); ?>
    <!-- START: HERO -->
    <section class="flex items-center hero">
        <div class="w-full absolute z-20 inset-0 md:relative md:w-1/2 text-center flex flex-col justify-center hero-caption">
            <h1 class="text-3xl md:text-5xl leading-tight font-semibold">
                EHPP <br class="" />Elektronik Harga Pokok Penjualan
            </h1>
            <h2 class="px-8 text-base md:px-0 md:text-lg my-6 tracking-wide">
                Hitung HPP Produk anda
                <br class="hidden lg:block" />secara digital dengan e-hpp.com
            </h2>
            <div>
                <a href="<?php echo e(route('register')); ?>" style="background-color: #14532d; color:white; font-style:bold"
                    class="bg-pink-400 text-black hover:bg-black hover:text-pink-400 rounded-full px-8 py-3 mt-4 inline-block flex-none transition duration-200">DAFTAR
                    AKUN
                </a>
            </div>
        </div>
        <div class="w-full inset-0 md:relative md:w-1/2">
            <div class="relative hero-image">
                <div class="overlay inset-0 bg-black opacity-35 z-10"></div>
                <div class="overlay right-0 bottom-0 md:inset-0">
                    <button class="video hero-cta focus:outline-none z-30 modal-trigger"
                        data-content='<div class="w-screen pb-56 md:w-88 md:pb-56 relative z-50">
              <div class="absolute w-full h-full">
                <iframe
                  width="100%"
                  height="100%"
                  src="https://www.youtube.com/embed/okgyt5WSit4"
                  frameborder="0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowfullscreen
                ></iframe>
              </div>
            </div>'></button>
                </div>
                <img src="<?php echo e(url('/frontend/images/content/background-image.png')); ?>" alt="hero 1"
                    class="absolute inset-0 md:relative w-full h-full object-cover object-center" />
            </div>
        </div>
    </section>
    <!-- END: HERO -->

    <!-- START: BROWSE THE ROOM -->
    
    <!-- END: BROWSE THE ROOM -->

    <!-- START: JUST ARRIVED -->
    
    <!-- END: JUST ARRIVED -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ehpp\resources\views/pages/frontend/index.blade.php ENDPATH**/ ?>