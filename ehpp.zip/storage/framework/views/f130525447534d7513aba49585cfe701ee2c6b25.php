  <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
       <?php $__env->slot('header', null, []); ?> 
          <h2 class="font-semibold text-xl text-gray-800 leading-tight">
              Mixing
          </h2>
       <?php $__env->endSlot(); ?>
      <!-- START: COMPLETE YOUR ROOM -->
      <section class="md:py-16">

          <div class="container mx-auto px-4">
              <div class="mt-5">
                  <a href="<?php echo e(route('dashboard.pakan.index')); ?>" style="background-color: #064e3b; color:white"
                      class=" bg-green-900 text-black hover:bg-black hover:text-green-400 focus:outline-none w-full py-3 rounded-full text-lg focus:text-black transition-all duration-200 px-6">
                      + Tambah Pakan
                  </a>
              </div>
              <div class="flex -mx-4 flex-wrap">
                  <div class="w-full px-4 mb-4 md:w-8/12 md:mb-0" id="shopping-cart">
                      <div class="flex flex-start mb-4 mt-8 pb-3 border-b border-gray-200 md:border-b-0">
                          <h3 class="text-2xl">Mixing Details</h3>
                      </div>

                      <div class="border-b border-gray-200 mb-4 hidden md:block">
                          <div class="flex flex-start items-center pb-2 -mx-4">
                              <div class="px-4 flex-none">
                                  <div class="" style="width: 90px">
                                      <h6>Foto</h6>
                                  </div>
                              </div>
                              <div class="px-4 w-5/12">
                                  <div class="">
                                      <h6>Pakan</h6>
                                  </div>
                              </div>
                              <div class="px-4 w-5/12">
                                  <div class="">
                                      <h6>Harga</h6>
                                  </div>
                              </div>
                              <div class="px-4 w-2/12">
                                  <div class="text-center">
                                      <h6>Mixing (Kg)</h6>
                                  </div>
                              </div>
                          </div>
                      </div>
                      

                      <!-- START: ROW 1 -->
                      <?php $__empty_1 = true; $__currentLoopData = auth()->user()->carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                          <div class="flex flex-start flex-wrap items-center mb-4 -mx-4" data-row="1">
                              <div class="px-4 flex-none">
                                  <div class="" style="width: 90px; height: 90px">
                                      
                                  </div>
                              </div>
                              <div class="px-4 w-auto flex-1 md:w-5/12">
                                  <div class="">
                                      <h6 class="font-semibold text-lg md:text-xl leading-8">
                                          <?php echo e($item->pakan->name); ?>

                                      </h6>
                                      <span class="text-sm md:text-lg">Hitung Ransum</span>
                                      <h6 class="font-semibold text-base md:text-lg block md:hidden">
                                          IDR <?php echo e(number_format($item->pakan->price)); ?>

                                      </h6>
                                  </div>
                              </div>
                              <div class="px-4 w-auto flex-none md:flex-1 md:w-5/12 hidden md:block">
                                  <div class="">
                                      <h6 class="font-semibold text-lg">IDR <?php echo e(number_format($item->pakan->price)); ?>

                                      </h6>
                                  </div>
                              </div>
                              
                          </div>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                          <p id="cart-empty" class=" text-center py-8">
                              Ooops... Cart is empty
                              <a href="<?php echo e(url('dashboard/pakan')); ?>" class="underline">Mixing Now</a>
                          </p>
                      <?php endif; ?>
                      <!-- END: ROW 1 -->




                      <br>
                      <br><br><br>
                      <hr>
                      <br>
                      <div class="bg-gray-100 px-4 py-6 md:p-8 md:rounded-3xl">
                          
                          <div class="text-center">
                              <a href="<?php echo e(url('/dashboard/mixing-store')); ?>"
                                  style="background-color:#064e3b; color:white; width:100% !important"
                                  class=" bg-pink-400 text-black hover:bg-black hover:text-pink-400 focus:outline-none w-full py-3 rounded-full text-lg focus:text-black transition-all duration-200 px-6">
                                  Hitung Harga Ransum
                              </a>
                          </div>
                          
                      </div>


                  </div>

                  
                  
              </div>
          </div>

          <!-- END: COMPLETE YOUR ROOM -->
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ehpp\resources\views/pages/dashboard/mixing/index.blade.php ENDPATH**/ ?>