  <?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
       <?php $__env->slot('header', null, []); ?> 
          <h2 class="font-semibold text-xl text-gray-800 leading-tight">
              Mixing
          </h2>
       <?php $__env->endSlot(); ?>
      <!-- START: COMPLETE YOUR ROOM -->
      <section class="md:py-16">

          <div class="container mx-auto px-4">
              <div class="mt-5">
                  <a href="<?php echo e(route('dashboard.pakan.index')); ?>" style="background-color: #064e3b; color:white"
                      class=" bg-green-900 text-black hover:bg-black hover:text-green-400 focus:outline-none w-full py-3 rounded-full text-lg focus:text-black transition-all duration-200 px-6">
                      + Tambah Pakan
                  </a>
              </div>
              <div class="flex -mx-4 flex-wrap">
                  <div class="w-full px-4 mb-4 md:w-8/12 md:mb-0" id="shopping-cart">
                      <div class="flex flex-start mb-4 mt-8 pb-3 border-b border-gray-200 md:border-b-0">
                          <h3 class="text-2xl">Mixing Details</h3>
                      </div>

                      <div class="border-b border-gray-200 mb-4 hidden md:block">
                          <div class="flex flex-start items-center pb-2 -mx-4">
                              <div class="px-4 flex-none">
                                  <div class="" style="width: 90px">
                                      <h6>Foto</h6>
                                  </div>
                              </div>
                              <div class="px-4 w-5/12">
                                  <div class="">
                                      <h6>Pakan</h6>
                                  </div>
                              </div>
                              <div class="px-4 w-5/12">
                                  <div class="">
                                      <h6>Harga</h6>
                                  </div>
                              </div>
                              <div class="px-4 w-2/12">
                                  <div class="text-center">
                                      <h6>Mixing (Kg)</h6>
                                  </div>
                              </div>
                          </div>
                      </div>
                      <p id="cart-empty" class=" text-center py-8">
                          Ooops... Mixing anda masih kosong
                          <a href="<?php echo e(route('index')); ?>" class="underline">Hitung sekarang</a>
                      </p>





                      <br>
                      <br><br><br>
                      <hr>
                      <br>
                      <div class="bg-gray-100 px-4 py-6 md:p-8 md:rounded-3xl">
                          <form action="<?php echo e(route('checkout')); ?>" method="POST">
                              <?php echo csrf_field(); ?>
                              <div class="text-center">
                                  <button type="submit" style="background-color:#064e3b; color:white;"
                                      class="bg-pink-400 text-black hover:bg-black hover:text-pink-400 focus:outline-none w-full py-3 rounded-full text-lg focus:text-black transition-all duration-200 px-6">
                                      Hitung Harga Ransum
                                  </button>
                              </div>
                          </form>
                      </div>


                  </div>

                  
                  
              </div>
          </div>

          <!-- END: COMPLETE YOUR ROOM -->
   <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ehpp\resources\views/pages/dashboard/product/index.blade.php ENDPATH**/ ?>