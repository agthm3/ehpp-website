<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Detail Pakan
        </h2>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            //Ajax Datatable

            var datatable = $('#crudTable').DataTable({
                ajax: {
                    url: '<?php echo url()->current(); ?>',
                },
                columns: [{
                        data: 'id',
                        name: 'id',
                        width: '5%'
                    },
                    {
                        data: 'pakan.name',
                        name: 'pakan.name'
                    },
                    {
                        data: 'pakan.price',
                        name: 'pakan.price'
                    },
                ],
            });
        </script>
     <?php $__env->endSlot(); ?>

    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <h2 class="font-semibold text-lg text-gray-800 leading-tight mb-5">Pakan Detail</h2>
            <br>
            <form action="<?php echo e(route('cart-add')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="idPakan" value="<?php echo e($pakan->id); ?>">
                <button class="bg-green-500 text-white rounded-md px-6 py-1 m-2" type="submit">Hitung</button>
            </form>
            <br>
            <hr>
            <div class="bg-white overflow-hidden shadow sm:rounded-lg mb-10">
                <div class="p-6 bg-white border-b border-gray-200">
                    <table class="table-auto w-full">
                        <tbody>
                            <tr>
                                <th class="border px-6 py-4 text-right">Name</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->name); ?></td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Harga</th>
                                <td class="border px-6 py-4 ">Rp<?php echo e(number_format($pakan->price)); ?></td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Protein</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->protein); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Lemak</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->lemak); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Serat</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->serat); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Energi</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->energi); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Ca</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->ca); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">P</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->p); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Mixing</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->mixing); ?>Kg</td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>

            <br>
            <hr>
            <h2 class="font-semibold text-lg text-gray-800 leading-tight mb-5">Kandungan Nutrisi</h2>
            <p class="muted-text">Kandungan Nutrisi terhitung otomatis</p>
            <div class="bg-white overflow-hidden shadow sm:rounded-lg mb-10">
                <div class="p-6 bg-white border-b border-gray-200">
                    <table class="table-auto w-full">
                        <tbody>
                            <tr>
                                <th class="border px-6 py-4 text-right">Protein</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->gprotein); ?>%
                                </td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Lemak</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->glemak); ?>%
                                </td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">S.Serat</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->gkasar); ?>%
                                </td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Energi</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->genergi); ?>%
                                </td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Ca</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->gca); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">P</th>
                                <td class="border px-6 py-4 "><?php echo e($pakan->gp); ?>%</td>
                            </tr>
                        </tbody>
                    </table>

                </div>
            </div>



            <div class="col-lg-6"><a href="<?php echo e(route('dashboard.pakan.edit', $item->id)); ?>"
                    class="bg-green-500 text-white rounded-md px-6 py-1 m-2">
                    Edit </a>



            </div>





            <div class="row">



                
            </div>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ehpp\resources\views/pages/dashboard/pakan/show.blade.php ENDPATH**/ ?>