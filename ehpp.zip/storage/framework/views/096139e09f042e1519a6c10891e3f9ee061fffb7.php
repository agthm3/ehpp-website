<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            Record
        </h2>
     <?php $__env->endSlot(); ?>

     <?php $__env->slot('script', null, []); ?> 
        <script>
            //Ajax Datatable

            var datatable = $('#crudTable').DataTable({

            });
        </script>
     <?php $__env->endSlot(); ?>

    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">

            <h2 class="font-semibold text-lg text-gray-800 leading-tight mb-5">Record Detail</h2>
            <br>
            <br>
            <hr>
            <div class="bg-white overflow-hidden shadow sm:rounded-lg mb-10">
                <div class="p-6 bg-white border-b border-gray-200">
                    <table class="table-auto w-full">
                        <label for="">Kandungan Gizi</label>
                        <tbody>
                            <tr>
                                <th class="border px-6 py-4 text-right">Protein</th>
                                <td class="border px-6 py-4 "><?php echo e($mixing->protein); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Lemak</th>
                                <td class="border px-6 py-4 "><?php echo e($mixing->lemak); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">S.Kasar</th>
                                <td class="border px-6 py-4 "><?php echo e($mixing->kasar); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">M.Energi</th>
                                <td class="border px-6 py-4 "><?php echo e($mixing->energi); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">Ca</th>
                                <td class="border px-6 py-4 "><?php echo e($mixing->ca); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-6 py-4 text-right">P</th>
                                <td class="border px-6 py-4 "><?php echo e($mixing->p); ?>%</td>
                            </tr>

                        </tbody>
                    </table>
                </div>
            </div>
            <br>
            <hr>

            <div class="bg-white overflow-hidden shadow sm:rounded-lg mb-10">
                <div class="p-6 bg-white border-b border-gray-200">
                    <table class="table-auto w-full">
                        <label for="">Total Harga/Pakan</label>
                        <tbody>
                            <?php $__currentLoopData = $total_per_pakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="border px-6 py-4 text-right"><?php echo e($item->pakan->name); ?></th>
                                    <td class="border px-6 py-4 ">Rp<?php echo e(number_format($item->total_harga)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>
            <br>
            <hr>

            <div class="bg-white overflow-hidden shadow sm:rounded-lg mb-10">
                <div class="p-6 bg-white border-b border-gray-200">
                    <table class="table-auto w-full">
                        <label for="">Total Harga (Semua Pakan) </label>
                        <tbody>
                            <tr>
                                <th class="border px-6 py-4 text-right">Total Harga(Rp)</th>
                                <td class="border px-6 py-4 ">Rp<?php echo e(number_format($total_semua_pakan->total_harga)); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <br>
            <hr>


            <div class="bg-white overflow-hidden shadow sm:rounded-lg mb-10">
                <div class="p-6 bg-white border-b border-gray-200">
                    <table class="table-auto w-full">
                        <label for="">Detail Pakan</label>
                        <tbody>

                            <?php $__currentLoopData = $total_per_pakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="border px-6 py-4 text-center"><?php echo e($item->pakan->name); ?></th>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>



            <div class="col-lg-6"><a href="#" class="bg-green-500 text-white rounded-md px-6 py-1 m-2">
                    Edit </a>



            </div>





        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\ehpp\resources\views/pages/dashboard/record/show.blade.php ENDPATH**/ ?>