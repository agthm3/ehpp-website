

<?php $__env->startSection('content'); ?>
    <div class="py-12">

        <div class="max-w-7xl mx-auto sm:px-4 lg:px-8">

            <h2 class="font-semibold text-lg text-gray-800 leading-tight mb-5">Record Detail >>
                <?php
                // Set the new timezone
                date_default_timezone_set('Asia/Makassar');
                $date = date('d-m-y h:i:s');
                echo $date;
                ?>
            </h2>


            <hr>
            <div class="bg-white overflow-hidden shadow sm:rounded-lg mb-10">
                <div class="p-6 bg-white border-b border-gray-200">
                    <table class="table-auto w-full">
                        <label for="">Kandungan Gizi</label>
                        <tbody>
                            <tr>
                                <th class="border px-4 py-2 text-right">Protein</th>
                                <td class="border px-4 py-2 "><?php echo e($mixing->protein); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-4 py-2 text-right">Lemak</th>
                                <td class="border px-4 py-2 "><?php echo e($mixing->lemak); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-4 py-2 text-right">S.Kasar</th>
                                <td class="border px-4 py-2 "><?php echo e($mixing->kasar); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-4 py-2 text-right">M.Energi</th>
                                <td class="border px-4 py-2 "><?php echo e($mixing->energi); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-4 py-2 text-right">Ca</th>
                                <td class="border px-4 py-2 "><?php echo e($mixing->ca); ?>%</td>
                            </tr>
                            <tr>
                                <th class="border px-4 py-2 text-right">P</th>
                                <td class="border px-4 py-2 "><?php echo e($mixing->p); ?>%</td>
                            </tr>

                        </tbody>
                    </table>
                    <table class="table-auto w-full">
                        <label for="">Total Harga/Pakan</label>
                        <tbody>

                            <?php $__currentLoopData = $total_per_pakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="border px-4 py-2 text-right"><?php echo e($item->pakan->name); ?></th>
                                    <td class="border px-4 py-2 ">Rp<?php echo e(number_format($item->total_harga)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                    <table class="table-auto w-full">
                        <label for="">Total Harga/Pakan</label>
                        <tbody>

                            <?php $__currentLoopData = $total_per_pakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="border px-4 py-2 text-right"><?php echo e($item->pakan->name); ?></th>
                                    <td class="border px-4 py-2 ">Rp<?php echo e(number_format($item->total_harga)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                    <table class="table-auto w-full">
                        <label for="">Total Harga (Semua Pakan) </label>
                        <tbody>
                            <tr>
                                <th class="border px-4 py-2 text-right">Total Harga(Rp)</th>
                                <td class="border px-4 py-2 ">Rp<?php echo e(number_format($total_semua_pakan->total_harga)); ?>

                                </td>
                            </tr>
                        </tbody>
                    </table>
                    <table class="table-auto w-full">
                        <label for="">Detail Pakan</label>
                        <tbody>

                            <?php $__currentLoopData = $total_per_pakan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th class="border px-4 py-2 text-center"><?php echo e($item->pakan->name); ?></th>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        </tbody>
                    </table>
                </div>
            </div>





        </div>
    </div>
    <script type="text/javascript">
        window.print();
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\ehpp\resources\views/pages/dashboard/print/show.blade.php ENDPATH**/ ?>