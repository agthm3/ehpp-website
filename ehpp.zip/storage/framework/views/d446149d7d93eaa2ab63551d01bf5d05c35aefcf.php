<img
              src="<?php echo e(url('/frontend/images/content/logos.png')); ?>"
              alt="EHPP - Hitung HPP kamu secara online"
            /><?php /**PATH C:\laragon\www\ehpp\resources\views/vendor/jetstream/components/application-logo.blade.php ENDPATH**/ ?>